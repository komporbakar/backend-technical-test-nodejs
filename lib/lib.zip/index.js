"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.app = void 0;
var _express = _interopRequireDefault(require("express"));
var _path = _interopRequireDefault(require("path"));
var _config = require("./config");
var _errorMiddleware = require("./middleware/error-middleware");
var _api = require("./router/api");
var _publicApi = require("./router/public-api");
var _logging = require("./utils/logging");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
var app = exports.app = (0, _express["default"])();
app.use(_express["default"].json());
app.use(_express["default"].urlencoded({
  extended: true
}));
app.use(_express["default"]["static"](_path["default"].join(__dirname, '../public')));
app.use('/uploads', _express["default"]["static"](_path["default"].join(__dirname, '../public/uploads')));
app.use(_publicApi.publicRouter);
app.use(_api.router);
app.use(_errorMiddleware.errorMiddleware);
app.use(function (req, res) {
  return res.status(404).json({
    status: 404,
    message: 'Not Found',
    data: null
  });
});
app.listen(_config.config.PORT, function () {
  return _logging.logging.info("Server running on port ".concat(_config.config.PORT));
});